package com.medicare;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

// Feature 5: Unit Testing
public class WardTest {

    private Ward ward;

    @BeforeEach
    public void setUp() {
        ward = new Ward();
    }

    private Patient outpatient(String id, String last) {
        return new Patient(id, "Sam", last, 30, "Male", "Flu", PatientCategory.OUTPATIENT);
    }

    private Inpatient inpatient(String id, String last) {
        return new Inpatient(id, "Amy", last, 40, "Female", "Fracture", Ward.WARD_NUMBER, 0);
    }

    // CRUD operation tests
    @Test
    public void testRegisterPatient() {
        assertTrue(ward.registerPatient(outpatient("P001", "Jones")));
        assertEquals(1, ward.getTotalPatients());
    }

    @Test
    public void testSearchPatient() {
        ward.registerPatient(outpatient("P001", "Jones"));
        Patient found = ward.searchPatient("P001");
        assertNotNull(found);
        assertEquals("Jones", found.getLastName());
        assertNull(ward.searchPatient("P999"));
    }

    @Test
    public void testUpdatePatient() {
        ward.registerPatient(outpatient("P001", "Jones"));
        assertTrue(ward.updatePatient("P001", "Samuel", "Smith", 31, "Male", "Cold"));
        Patient p = ward.searchPatient("P001");
        assertEquals("Samuel", p.getFirstName());
        assertEquals("Smith", p.getLastName());
        assertEquals(31, p.getAge());
        assertEquals("Cold", p.getMedicalCondition());
        assertFalse(ward.updatePatient("P999", "A", "B", 1, "Male", "None"));
    }

    @Test
    public void testDeletePatient() {
        ward.registerPatient(outpatient("P001", "Jones"));
        assertTrue(ward.deletePatient("P001"));
        assertEquals(0, ward.getTotalPatients());
        assertNull(ward.searchPatient("P001"));
        assertFalse(ward.deletePatient("P001"));
    }

    @Test
    public void testDeleteInpatientReleasesBed() {
        ward.registerPatient(inpatient("P001", "Jones"));
        ward.allocateBed("P001");
        ward.deletePatient("P001");
        assertEquals(0, ward.getOccupiedBedCount());
    }

    // Bed management tests
    @Test
    public void testAllocateBed() {
        ward.registerPatient(inpatient("P001", "Jones"));
        int bed = ward.allocateBed("P001");
        assertEquals(1, bed);
        assertEquals(1, ((Inpatient) ward.searchPatient("P001")).getBedNumber());
        assertTrue(ward.isBedOccupied(1));
        assertEquals(1, ward.getOccupiedBedCount());
    }

    @Test
    public void testReleaseBed() {
        ward.registerPatient(inpatient("P001", "Jones"));
        ward.allocateBed("P001");
        assertTrue(ward.releaseBed("P001"));
        assertFalse(ward.isBedOccupied(1));
        assertEquals(0, ((Inpatient) ward.searchPatient("P001")).getBedNumber());
        assertEquals(20, ward.getAvailableBedCount());
        assertFalse(ward.releaseBed("P001"));
    }

    @Test
    public void testOutpatientCannotGetBed() {
        ward.registerPatient(outpatient("P001", "Jones"));
        assertEquals(Ward.NOT_INPATIENT, ward.allocateBed("P001"));
        assertEquals(0, ward.getOccupiedBedCount());
    }

    @Test
    public void testInpatientCannotHaveTwoBeds() {
        ward.registerPatient(inpatient("P001", "Jones"));
        ward.allocateBed("P001");
        assertEquals(Ward.ALREADY_HAS_BED, ward.allocateBed("P001"));
        assertEquals(1, ward.getOccupiedBedCount());
    }

    // Validation and boundary tests
    @Test
    public void testPreventDuplicatePatientIds() {
        assertTrue(ward.registerPatient(outpatient("P001", "Jones")));
        assertFalse(ward.registerPatient(outpatient("P001", "Smith")));
        assertEquals(1, ward.getTotalPatients());
    }

    @Test
    public void testPreventAllocatingOccupiedBed() {
        ward.registerPatient(inpatient("P001", "Jones"));
        ward.registerPatient(inpatient("P002", "Smith"));
        assertEquals(5, ward.allocateBed("P001", 5));
        assertEquals(Ward.BED_OCCUPIED, ward.allocateBed("P002", 5));
        assertEquals(0, ((Inpatient) ward.searchPatient("P002")).getBedNumber());
    }

    @Test
    public void testInvalidBedNumber() {
        ward.registerPatient(inpatient("P001", "Jones"));
        assertEquals(Ward.INVALID_BED, ward.allocateBed("P001", 0));
        assertEquals(Ward.INVALID_BED, ward.allocateBed("P001", 21));
    }

    @Test
    public void testPreventAllocationWhenAllBedsOccupied() {
        for (int i = 1; i <= 20; i++) {
            ward.registerPatient(inpatient("P" + i, "Surname" + i));
            assertEquals(i, ward.allocateBed("P" + i));
        }
        assertEquals(0, ward.getAvailableBedCount());
        assertEquals(100.0, ward.getOccupancyPercentage(), 0.001);

        ward.registerPatient(inpatient("P21", "Extra"));
        assertEquals(Ward.WARD_FULL, ward.allocateBed("P21"));
        assertEquals(20, ward.getOccupiedBedCount());
    }

    @Test
    public void testOccupancyPercentage() {
        ward.registerPatient(inpatient("P001", "Jones"));
        ward.registerPatient(inpatient("P002", "Smith"));
        ward.allocateBed("P001");
        ward.allocateBed("P002");
        assertEquals(10.0, ward.getOccupancyPercentage(), 0.001);
    }

    @Test
    public void testSortBySurname() {
        ward.registerPatient(outpatient("P003", "Zulu"));
        ward.registerPatient(outpatient("P001", "Adams"));
        ward.registerPatient(outpatient("P002", "Mokoena"));
        ward.sortBySurname();
        assertEquals("Adams", ward.getPatients().get(0).getLastName());
        assertEquals("Mokoena", ward.getPatients().get(1).getLastName());
        assertEquals("Zulu", ward.getPatients().get(2).getLastName());
    }

    @Test
    public void testSortByPatientId() {
        ward.registerPatient(outpatient("P003", "Zulu"));
        ward.registerPatient(outpatient("P001", "Adams"));
        ward.registerPatient(outpatient("P002", "Mokoena"));
        ward.sortByPatientId();
        assertEquals("P001", ward.getPatients().get(0).getPatientId());
        assertEquals("P002", ward.getPatients().get(1).getPatientId());
        assertEquals("P003", ward.getPatients().get(2).getPatientId());
    }

    @Test
    public void testInpatientIsAPatientWithWardAndBed() {
        Inpatient in = inpatient("P001", "Jones");
        assertTrue(in instanceof Patient);
        assertEquals(PatientCategory.INPATIENT, in.getCategory());
        assertEquals(Ward.WARD_NUMBER, in.getWardNumber());
        assertEquals("None", in.getBedCode());
    }
}
