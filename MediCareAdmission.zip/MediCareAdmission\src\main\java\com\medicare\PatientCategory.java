package com.medicare;

// Feature 4: Patient categories (enum)
public enum PatientCategory {
    INPATIENT,
    OUTPATIENT,
    EMERGENCY;

    public static PatientCategory fromText(String text) {
        if (text == null) {
            return null;
        }
        String t = text.trim().toUpperCase();
        for (PatientCategory c : PatientCategory.values()) {
            if (c.name().equals(t)) {
                return c;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        String name = name();
        return name.charAt(0) + name.substring(1).toLowerCase();
    }
}
