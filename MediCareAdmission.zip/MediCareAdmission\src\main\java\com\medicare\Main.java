package com.medicare;

import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);
    private static Ward ward = new Ward();

    // Features 1 - 3: Menu
    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            showMenu();
            int choice = readInt("Enter your choice: ");
            System.out.println();
            switch (choice) {
                case 1:
                    registerPatient();
                    break;
                case 2:
                    searchPatient();
                    break;
                case 3:
                    updatePatient();
                    break;
                case 4:
                    deletePatient();
                    break;
                case 5:
                    ward.displayAllPatients();
                    break;
                case 6:
                    allocateBed();
                    break;
                case 7:
                    releaseBed();
                    break;
                case 8:
                    ward.displayWardLayout();
                    break;
                case 9:
                    ward.displayAvailableBeds();
                    break;
                case 10:
                    ward.displayOccupiedBeds();
                    break;
                case 11:
                    ward.displayWardReport();
                    break;
                case 12:
                    ward.sortBySurname();
                    System.out.println("Patients sorted by surname.");
                    ward.displayAllPatients();
                    break;
                case 13:
                    ward.sortByPatientId();
                    System.out.println("Patients sorted by Patient ID.");
                    ward.displayAllPatients();
                    break;
                case 0:
                    System.out.println("Thank you for using the MediCare Admission System. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please pick a number from the menu.");
            }
            System.out.println();
        }
    }

    private static void showMenu() {
        System.out.println("==========================================");
        System.out.println("   MEDICARE HOSPITAL - PATIENT ADMISSION  ");
        System.out.println("==========================================");
        System.out.println(" PATIENTS");
        System.out.println("  1. Register a new patient");
        System.out.println("  2. Search for a patient");
        System.out.println("  3. Update a patient");
        System.out.println("  4. Delete a patient");
        System.out.println("  5. Display all patients");
        System.out.println(" BEDS");
        System.out.println("  6. Allocate a bed to an inpatient");
        System.out.println("  7. Release a bed (discharge)");
        System.out.println("  8. Display ward layout");
        System.out.println("  9. Display available beds");
        System.out.println(" 10. Display occupied beds");
        System.out.println(" REPORTS");
        System.out.println(" 11. Ward report (totals and occupancy)");
        System.out.println(" 12. Sort patients by surname");
        System.out.println(" 13. Sort patients by Patient ID");
        System.out.println("  0. Exit");
        System.out.println("------------------------------------------");
    }

    // Feature 1: Patient Management
    private static void registerPatient() {
        System.out.println("--- Register a new patient ---");
        String id = readText("Patient ID: ");
        if (id.equals("")) {
            System.out.println("The Patient ID cannot be empty.");
            return;
        }
        if (ward.searchPatient(id) != null) {
            System.out.println("A patient with ID " + id + " is already registered.");
            return;
        }
        String firstName = readText("First name: ");
        String lastName = readText("Last name: ");
        if (firstName.equals("") || lastName.equals("")) {
            System.out.println("The first name and last name cannot be empty.");
            return;
        }
        int age = readInt("Age: ");
        if (age < 0 || age > 120) {
            System.out.println("Invalid age. It must be between 0 and 120.");
            return;
        }
        String gender = readGender();
        String condition = readText("Medical condition: ");

        System.out.println("Patient category: 1. Inpatient  2. Outpatient  3. Emergency");
        int categoryChoice = readInt("Choose a category: ");

        Patient patient;
        if (categoryChoice == 1) {
            patient = new Inpatient(id, firstName, lastName, age, gender, condition,
                    Ward.WARD_NUMBER, 0);
        } else if (categoryChoice == 2) {
            patient = new Patient(id, firstName, lastName, age, gender, condition,
                    PatientCategory.OUTPATIENT);
        } else if (categoryChoice == 3) {
            patient = new Patient(id, firstName, lastName, age, gender, condition,
                    PatientCategory.EMERGENCY);
        } else {
            System.out.println("Invalid category. The patient was not registered.");
            return;
        }

        if (ward.registerPatient(patient)) {
            System.out.println("Patient registered successfully.");
            if (categoryChoice == 1) {
                System.out.println("Use option 6 to allocate this inpatient a bed.");
            }
        } else {
            System.out.println("The patient could not be registered.");
        }
    }

    private static void searchPatient() {
        System.out.println("--- Search for a patient ---");
        String id = readText("Patient ID: ");
        Patient patient = ward.searchPatient(id);
        if (patient == null) {
            System.out.println("No patient found with ID " + id + ".");
        } else {
            System.out.println();
            patient.displayDetails();
        }
    }

    private static void updatePatient() {
        System.out.println("--- Update a patient ---");
        String id = readText("Patient ID: ");
        Patient patient = ward.searchPatient(id);
        if (patient == null) {
            System.out.println("No patient found with ID " + id + ".");
            return;
        }
        System.out.println("Current details:");
        patient.displayDetails();
        System.out.println();
        System.out.println("Enter the new details (the category and bed cannot be changed here).");

        String firstName = readText("First name: ");
        String lastName = readText("Last name: ");
        if (firstName.equals("") || lastName.equals("")) {
            System.out.println("The first name and last name cannot be empty. Nothing was changed.");
            return;
        }
        int age = readInt("Age: ");
        if (age < 0 || age > 120) {
            System.out.println("Invalid age. Nothing was changed.");
            return;
        }
        String gender = readGender();
        String condition = readText("Medical condition: ");

        ward.updatePatient(id, firstName, lastName, age, gender, condition);
        System.out.println("Patient updated successfully.");
    }

    private static void deletePatient() {
        System.out.println("--- Delete a patient ---");
        String id = readText("Patient ID: ");
        if (ward.deletePatient(id)) {
            System.out.println("Patient deleted (and their bed released if they had one).");
        } else {
            System.out.println("No patient found with ID " + id + ".");
        }
    }

    // Feature 2: Bed Management
    private static void allocateBed() {
        System.out.println("--- Allocate a bed ---");
        String id = readText("Patient ID of the inpatient: ");
        ward.displayAvailableBeds();
        int bed = readInt("Bed number to use (1-20), or 0 for the first free bed: ");

        int result;
        if (bed == 0) {
            result = ward.allocateBed(id);
        } else {
            result = ward.allocateBed(id, bed);
        }

        switch (result) {
            case Ward.NOT_FOUND:
                System.out.println("No patient found with ID " + id + ".");
                break;
            case Ward.NOT_INPATIENT:
                System.out.println("Only inpatients can be allocated a bed.");
                break;
            case Ward.ALREADY_HAS_BED:
                System.out.println("This inpatient already has a bed. Release it first.");
                break;
            case Ward.WARD_FULL:
                System.out.println("There are no beds available. The ward is full.");
                break;
            case Ward.INVALID_BED:
                System.out.println("Invalid bed number. Choose between 1 and 20.");
                break;
            case Ward.BED_OCCUPIED:
                System.out.println("That bed is already occupied.");
                break;
            default:
                System.out.println("Bed " + String.format("B%02d", result) + " allocated successfully.");
        }
    }

    private static void releaseBed() {
        System.out.println("--- Release a bed ---");
        String id = readText("Patient ID of the inpatient being discharged: ");
        if (ward.releaseBed(id)) {
            System.out.println("The bed has been released.");
        } else {
            System.out.println("That patient was not found, is not an inpatient, or has no bed.");
        }
    }

    // Input helpers
    private static String readText(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("That is not a valid number. Please try again.");
            }
        }
    }

    private static String readGender() {
        while (true) {
            String gender = readText("Gender (Male/Female/Other): ");
            if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("Female")
                    || gender.equalsIgnoreCase("Other")) {
                return gender;
            }
            System.out.println("Please type Male, Female or Other.");
        }
    }
}
