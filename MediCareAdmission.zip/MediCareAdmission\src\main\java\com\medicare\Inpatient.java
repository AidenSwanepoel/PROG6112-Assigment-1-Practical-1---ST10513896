package com.medicare;

// Feature 4: Inpatient class (inheritance)
public class Inpatient extends Patient {

    private int wardNumber;
    private int bedNumber;

    public Inpatient(String patientId, String firstName, String lastName, int age,
                     String gender, String medicalCondition, int wardNumber, int bedNumber) {
        super(patientId, firstName, lastName, age, gender, medicalCondition,
                PatientCategory.INPATIENT);
        this.wardNumber = wardNumber;
        this.bedNumber = bedNumber;
    }

    public int getWardNumber() {
        return wardNumber;
    }

    public void setWardNumber(int wardNumber) {
        this.wardNumber = wardNumber;
    }

    public int getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(int bedNumber) {
        this.bedNumber = bedNumber;
    }

    public String getBedCode() {
        if (bedNumber == 0) {
            return "None";
        }
        return String.format("B%02d", bedNumber);
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Ward number       : " + wardNumber);
        System.out.println("Bed number        : " + getBedCode());
    }
}
