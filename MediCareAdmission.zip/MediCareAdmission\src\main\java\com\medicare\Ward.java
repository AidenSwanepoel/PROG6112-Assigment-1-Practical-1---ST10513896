package com.medicare;

import java.util.ArrayList;

public class Ward {

    public static final int ROWS = 4;
    public static final int COLUMNS = 5;
    public static final int WARD_NUMBER = 1;

    private String[][] beds = new String[ROWS][COLUMNS];
    private ArrayList<Patient> patients = new ArrayList<>();

    public Ward() {
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                beds[row][col] = "";
            }
        }
    }

    // Feature 1: Patient Management
    public boolean registerPatient(Patient patient) {
        if (patient == null || searchPatient(patient.getPatientId()) != null) {
            return false;
        }
        patients.add(patient);
        return true;
    }

    public Patient searchPatient(String patientId) {
        for (Patient p : patients) {
            if (p.getPatientId().equalsIgnoreCase(patientId)) {
                return p;
            }
        }
        return null;
    }

    public boolean updatePatient(String patientId, String firstName, String lastName,
                                 int age, String gender, String condition) {
        Patient p = searchPatient(patientId);
        if (p == null) {
            return false;
        }
        p.setFirstName(firstName);
        p.setLastName(lastName);
        p.setAge(age);
        p.setGender(gender);
        p.setMedicalCondition(condition);
        return true;
    }

    public boolean deletePatient(String patientId) {
        Patient p = searchPatient(patientId);
        if (p == null) {
            return false;
        }
        if (p instanceof Inpatient) {
            releaseBed(patientId);
        }
        patients.remove(p);
        return true;
    }

    public ArrayList<Patient> getPatients() {
        return patients;
    }

    public int getTotalPatients() {
        return patients.size();
    }

    // Feature 2: Bed Management
    public static final int NOT_FOUND = -1;
    public static final int NOT_INPATIENT = -2;
    public static final int ALREADY_HAS_BED = -3;
    public static final int WARD_FULL = -4;
    public static final int INVALID_BED = -5;
    public static final int BED_OCCUPIED = -6;

    public int allocateBed(String patientId) {
        int check = checkCanAllocate(patientId);
        if (check != 0) {
            return check;
        }
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                if (beds[row][col].equals("")) {
                    return putPatientInBed(patientId, row, col);
                }
            }
        }
        return WARD_FULL;
    }

    public int allocateBed(String patientId, int bedNumber) {
        int check = checkCanAllocate(patientId);
        if (check != 0) {
            return check;
        }
        if (bedNumber < 1 || bedNumber > ROWS * COLUMNS) {
            return INVALID_BED;
        }
        int row = (bedNumber - 1) / COLUMNS;
        int col = (bedNumber - 1) % COLUMNS;
        if (!beds[row][col].equals("")) {
            return BED_OCCUPIED;
        }
        return putPatientInBed(patientId, row, col);
    }

    private int checkCanAllocate(String patientId) {
        Patient p = searchPatient(patientId);
        if (p == null) {
            return NOT_FOUND;
        }
        if (!(p instanceof Inpatient)) {
            return NOT_INPATIENT;
        }
        if (((Inpatient) p).getBedNumber() != 0) {
            return ALREADY_HAS_BED;
        }
        if (getAvailableBedCount() == 0) {
            return WARD_FULL;
        }
        return 0;
    }

    private int putPatientInBed(String patientId, int row, int col) {
        Inpatient inpatient = (Inpatient) searchPatient(patientId);
        int bedNumber = row * COLUMNS + col + 1;
        beds[row][col] = inpatient.getPatientId();
        inpatient.setBedNumber(bedNumber);
        return bedNumber;
    }

    public boolean releaseBed(String patientId) {
        Patient p = searchPatient(patientId);
        if (p == null || !(p instanceof Inpatient)) {
            return false;
        }
        Inpatient inpatient = (Inpatient) p;
        if (inpatient.getBedNumber() == 0) {
            return false;
        }
        int row = (inpatient.getBedNumber() - 1) / COLUMNS;
        int col = (inpatient.getBedNumber() - 1) % COLUMNS;
        beds[row][col] = "";
        inpatient.setBedNumber(0);
        return true;
    }

    public boolean isBedOccupied(int bedNumber) {
        if (bedNumber < 1 || bedNumber > ROWS * COLUMNS) {
            return false;
        }
        int row = (bedNumber - 1) / COLUMNS;
        int col = (bedNumber - 1) % COLUMNS;
        return !beds[row][col].equals("");
    }

    public int getOccupiedBedCount() {
        int count = 0;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                if (!beds[row][col].equals("")) {
                    count++;
                }
            }
        }
        return count;
    }

    public int getAvailableBedCount() {
        return ROWS * COLUMNS - getOccupiedBedCount();
    }

    public double getOccupancyPercentage() {
        return getOccupiedBedCount() * 100.0 / (ROWS * COLUMNS);
    }

    public void displayWardLayout() {
        System.out.println("---------- WARD LAYOUT ----------");
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                String code = String.format("B%02d", row * COLUMNS + col + 1);
                if (beds[row][col].equals("")) {
                    System.out.print(code + "      ");
                } else {
                    System.out.print(code + "[X]   ");
                }
            }
            System.out.println();
        }
        System.out.println("[X] = occupied");
    }

    public void displayAvailableBeds() {
        System.out.println("---------- AVAILABLE BEDS ----------");
        int count = 0;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                if (beds[row][col].equals("")) {
                    System.out.print(String.format("B%02d", row * COLUMNS + col + 1) + "  ");
                    count++;
                }
            }
        }
        if (count == 0) {
            System.out.print("No beds are available.");
        }
        System.out.println();
    }

    public void displayOccupiedBeds() {
        System.out.println("---------- OCCUPIED BEDS ----------");
        int count = 0;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                if (!beds[row][col].equals("")) {
                    String code = String.format("B%02d", row * COLUMNS + col + 1);
                    Patient p = searchPatient(beds[row][col]);
                    System.out.println(code + " - " + p.getFirstName() + " " + p.getLastName()
                            + " (" + p.getPatientId() + ")");
                    count++;
                }
            }
        }
        if (count == 0) {
            System.out.println("No beds are occupied.");
        }
    }

    // Feature 3: Reports
    public void displayAllPatients() {
        System.out.println("---------- ALL REGISTERED PATIENTS ----------");
        if (patients.isEmpty()) {
            System.out.println("No patients are registered.");
            return;
        }
        for (Patient p : patients) {
            p.displayDetails();
            System.out.println("-----------------------------------");
        }
    }

    // Feature 3: Sorting
    public void sortBySurname() {
        for (int i = 0; i < patients.size() - 1; i++) {
            for (int j = 0; j < patients.size() - 1 - i; j++) {
                String first = patients.get(j).getLastName();
                String second = patients.get(j + 1).getLastName();
                if (first.compareToIgnoreCase(second) > 0) {
                    Patient temp = patients.get(j);
                    patients.set(j, patients.get(j + 1));
                    patients.set(j + 1, temp);
                }
            }
        }
    }

    public void sortByPatientId() {
        for (int i = 0; i < patients.size() - 1; i++) {
            for (int j = 0; j < patients.size() - 1 - i; j++) {
                String first = patients.get(j).getPatientId();
                String second = patients.get(j + 1).getPatientId();
                if (first.compareToIgnoreCase(second) > 0) {
                    Patient temp = patients.get(j);
                    patients.set(j, patients.get(j + 1));
                    patients.set(j + 1, temp);
                }
            }
        }
    }

    public void displayWardReport() {
        System.out.println("========== WARD REPORT ==========");
        System.out.println("Total registered patients : " + getTotalPatients());
        System.out.println("Total beds                : " + (ROWS * COLUMNS));
        System.out.println("Total occupied beds       : " + getOccupiedBedCount());
        System.out.println("Total available beds      : " + getAvailableBedCount());
        System.out.printf("Ward occupancy            : %.1f%%%n", getOccupancyPercentage());
        System.out.println("=================================");
        displayAvailableBeds();
        displayOccupiedBeds();
    }
}
